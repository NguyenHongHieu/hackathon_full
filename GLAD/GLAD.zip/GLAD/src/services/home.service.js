/**
 * Define all services for home route
 */
const HomeService = {};
export default HomeService;