import Redis from "./redis";

const UserRedis = {};

// UserRedis.storeSession = async (object) => {
//     await Redis.setHashCache('users', object._id)
// }

export default UserRedis;
