/**
 * Define all constants for VI location
 */
const messageError = {
    password: "Bạn nhập sai mật khẩu",
}

export const messErr = messageError;