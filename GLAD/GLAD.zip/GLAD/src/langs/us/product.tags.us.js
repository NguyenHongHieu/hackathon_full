const tags = [
    {name: "", code: ""}
]

module.exports = tags;