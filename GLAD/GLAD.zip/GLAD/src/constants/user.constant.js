const UserConstants = {
    status: [
        {name: 'admin', code: 1},
        {name: 'buyer', code: 2},
        {name: 'seller', code: 3},
        {name: 'pending', code: 1},
    ]
}

export default UserConstants;
